from fastapi import FastAPI
from app.routes import movies, users, auth

app = FastAPI(title="OTT Platform API")

app.include_router(movies.router)
app.include_router(users.router)
app.include_router(auth.router)

@app.get("/")
def home():
    return {"message": "OTT Platform API running"}
